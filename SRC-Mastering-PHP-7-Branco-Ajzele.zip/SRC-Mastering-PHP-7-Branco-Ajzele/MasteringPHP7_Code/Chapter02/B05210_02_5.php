<?php

class xmlParser
{
 // body
}

class XML_Parser
{
 // body
}
