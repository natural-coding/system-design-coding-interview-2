<?php

class Employee
{
  public function pay()
  {
    // body
  }
}
