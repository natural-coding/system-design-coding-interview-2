<?php

namespace Foggyline\User\Model;

use Foggyline\User\Model\Director;

class Employee
{
}
