<?php

class Employee
{
 // body
}
