var_dump(is_callable($user)); // true
