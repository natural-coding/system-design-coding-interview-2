object(User)#2 (4) {
  ["name"]=> string(6) "Mariya"
  ["age"]=> int(32)
  ["salary":"User":private]=> float(4200)
  ["identifier":protected]=> string(3) "ABC"
}
