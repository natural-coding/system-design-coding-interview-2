__callStatic => hello: John, 34
bonus: 560
__callStatic => salary: 4200
