 string(4) "John" int(34)
