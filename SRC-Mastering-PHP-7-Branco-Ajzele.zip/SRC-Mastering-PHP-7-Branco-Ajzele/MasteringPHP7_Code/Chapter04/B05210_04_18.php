public mixed __call(string $name, array $arguments)
