__get => name: Marry

__get => age: 32

4200

PHP Notice: Undefined property: message in...
