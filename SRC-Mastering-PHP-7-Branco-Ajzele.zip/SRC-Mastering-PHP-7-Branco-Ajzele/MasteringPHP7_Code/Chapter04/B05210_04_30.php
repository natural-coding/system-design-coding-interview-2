object(User)#1 (4) {
  ["data":"User":private]=> array(3) {
    ["name"]=> string(4) "John"
    ["age"]=> int(34)
    ["message"]=> string(5) "hello"
  }
  ["name":"User":private]=> NULL
  ["age":protected]=> NULL
  ["salary"]=> float(4200)
}
