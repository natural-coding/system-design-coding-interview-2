mixed __invoke([ $... ])
