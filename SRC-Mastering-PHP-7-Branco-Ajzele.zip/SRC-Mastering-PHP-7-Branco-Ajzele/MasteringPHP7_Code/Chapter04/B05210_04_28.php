public void __set(string $name, mixed $value)
