echo 'A';
$user = new User();
echo 'B';

// outputs "AB__destruct"
