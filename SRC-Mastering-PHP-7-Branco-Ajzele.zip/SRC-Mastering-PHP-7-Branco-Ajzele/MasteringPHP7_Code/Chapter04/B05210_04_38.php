public bool __unset(string $name)
