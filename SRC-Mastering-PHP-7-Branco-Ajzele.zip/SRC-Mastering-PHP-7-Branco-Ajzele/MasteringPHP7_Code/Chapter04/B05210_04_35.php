public bool __isset(string $name)
