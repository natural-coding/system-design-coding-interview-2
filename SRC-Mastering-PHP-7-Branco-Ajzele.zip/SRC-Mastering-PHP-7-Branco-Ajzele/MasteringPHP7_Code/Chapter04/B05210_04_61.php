User::__set_state(array(
 'name' => 'John',
 'age' => 34,
 'salary' => 4200.0,
 'identifier' => 'ABC',
))

string(113) "User::__set_state(array(
 'name' => 'John',
 'age' => 34,
 'salary' => 4200.0,
 'identifier' => 'ABC',
))"
