object(User)#1 (1) {
  ["identifier"]=> string(4) "john"
}

object(User)#2 (1) {
  ["identifier"]=> NULL
}
