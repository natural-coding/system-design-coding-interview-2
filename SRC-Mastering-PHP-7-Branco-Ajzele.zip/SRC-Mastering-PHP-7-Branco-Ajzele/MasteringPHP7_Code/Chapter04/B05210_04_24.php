public static mixed __callStatic (string $name, array $arguments)
