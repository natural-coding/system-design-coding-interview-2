PHP Warning: Division by zero
