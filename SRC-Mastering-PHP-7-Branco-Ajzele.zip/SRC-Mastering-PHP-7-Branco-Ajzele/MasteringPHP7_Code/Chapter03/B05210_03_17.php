 Caught: Division of PHP_INT_MIN by -1 is not an integer
