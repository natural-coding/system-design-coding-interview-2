    bool trigger_error (
      string $error_msg
      [, int $error_type = E_USER_NOTICE ]
    )
