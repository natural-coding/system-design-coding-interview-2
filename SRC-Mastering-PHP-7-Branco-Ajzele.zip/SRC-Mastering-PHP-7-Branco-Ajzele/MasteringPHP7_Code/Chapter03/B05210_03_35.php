    mixed set_error_handler (
      callable $error_handler
      [, int $error_types = E_ALL | E_STRICT ]
    )
