    bool handler (
      int $errno ,
      string $errstr
      [, string $errfile
        [, int $errline
          [, array $errcontext ]]]
    )
