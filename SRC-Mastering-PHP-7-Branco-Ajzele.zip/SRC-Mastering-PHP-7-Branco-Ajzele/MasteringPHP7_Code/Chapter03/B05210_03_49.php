    bool error_log (
       string $message
      [, int $message_type = 0
        [, string $destination
          [, string $extra_headers ] ]]
    )
