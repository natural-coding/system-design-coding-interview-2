 Caught: Bit shift by negative number
