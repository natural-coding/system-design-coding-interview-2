try {
      // ...
    }
catch (\InvalidArgumentException | \LengthException $e)
   {
     // ...
   }
catch (\Exception $e)
   {
     // ...
   }
 finally
   {
    // ...
   }
