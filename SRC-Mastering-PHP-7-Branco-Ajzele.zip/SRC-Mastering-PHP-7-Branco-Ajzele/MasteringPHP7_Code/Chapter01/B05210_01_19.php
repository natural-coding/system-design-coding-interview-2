$foo()['bar']();

[$obj1, $obj2][0]->prop;

getStr(){0}

$foo['bar']::$baz;

$foo::$bar::$baz;

$foo->bar()::baz()

// Assuming extension that implements actual toLower behavior
"PHP"->toLower();

[$obj, 'method']();

'Foo'::$bar;
