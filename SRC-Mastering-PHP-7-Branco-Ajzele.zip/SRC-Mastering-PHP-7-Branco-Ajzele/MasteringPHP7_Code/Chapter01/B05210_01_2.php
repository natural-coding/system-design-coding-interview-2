function addTab($tab) {
 if (is_array($tab)) {

    } elseif (is_object($tab)) {

    } elseif (is_string($tab)) {

    } else {

    }
}
