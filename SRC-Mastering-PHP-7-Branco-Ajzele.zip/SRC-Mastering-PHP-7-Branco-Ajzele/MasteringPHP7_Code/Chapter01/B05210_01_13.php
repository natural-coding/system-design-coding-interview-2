$name = $_GET['name'] ?? 'N/A';
