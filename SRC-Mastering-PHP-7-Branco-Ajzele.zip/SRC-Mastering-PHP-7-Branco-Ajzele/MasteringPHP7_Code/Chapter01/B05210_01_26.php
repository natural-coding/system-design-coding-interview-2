use Magento\Backend\Block\Widget\{
  Grid
  Grid\Column,
  Grid\Extended
};
