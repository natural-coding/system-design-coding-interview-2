<?xml version="1.0" encoding="UTF-8"?>
<customer>
<name type="string"><![CDATA[John]]></name>
<age type="integer">34</age>
<addresses>
<address><![CDATA[The Address #1]]></address>
</addresses>
</customer>
