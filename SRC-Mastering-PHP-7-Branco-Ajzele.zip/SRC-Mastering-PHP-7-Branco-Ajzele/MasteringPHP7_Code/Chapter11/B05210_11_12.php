<?php

namespace Foggyline;

class User
{
    /**
     * Says "Welcome user..."
     * @param $name
     * @return string
     */
    function welcome($name)
    {
        return 'Welcome user: ' . $name;
    }
}

