<?php

$user = json_decode('{"name":"John","age":34,"salary":4200.5}');

print_r($user);

//    stdClass Object
//    (
//        [name] => John
//        [age] => 34
//        [salary] => 4200.5
//    )
