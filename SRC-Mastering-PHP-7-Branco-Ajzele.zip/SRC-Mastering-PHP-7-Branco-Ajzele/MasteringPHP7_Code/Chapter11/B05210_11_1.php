{
"base": "EUR",
"date": "2017-03-10",
"rates": {
"GBP": 0.8725,
"HRK": 7.419,
"USD": 1.0606
  }
}
