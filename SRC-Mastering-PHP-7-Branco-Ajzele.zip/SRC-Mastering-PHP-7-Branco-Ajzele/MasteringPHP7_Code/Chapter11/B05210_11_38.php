thrift -r -gen php:server Greeting.thrift
