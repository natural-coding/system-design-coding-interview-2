namespace php user

service GreetingService
{
 string hello(1: string name),
 string goodbye()
}
