composer require silex/silex "~2.0"
