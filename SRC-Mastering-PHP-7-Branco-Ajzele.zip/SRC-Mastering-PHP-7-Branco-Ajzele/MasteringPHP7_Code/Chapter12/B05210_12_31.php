sudo systemctl status mongodb.service
