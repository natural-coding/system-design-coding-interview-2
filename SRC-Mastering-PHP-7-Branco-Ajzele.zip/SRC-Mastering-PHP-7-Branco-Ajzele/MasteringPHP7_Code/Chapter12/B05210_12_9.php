show databases;
use sakila;
show tables;
