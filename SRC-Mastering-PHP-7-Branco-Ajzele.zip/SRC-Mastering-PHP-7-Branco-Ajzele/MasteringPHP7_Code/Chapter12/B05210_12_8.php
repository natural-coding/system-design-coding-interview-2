// Either this command
mysql -uroot -p < sakila-data.sql

// Either this command
mysql -uroot -p -e "SOURCE sakila-data.sql"
