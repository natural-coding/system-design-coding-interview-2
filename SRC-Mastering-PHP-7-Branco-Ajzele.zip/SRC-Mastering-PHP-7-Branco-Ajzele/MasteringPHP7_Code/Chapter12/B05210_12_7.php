// Either this command
mysql -uroot -p < sakila-schema.sql

// Either this command
mysql -uroot -p -e "SOURCE sakila-schema.sql"
