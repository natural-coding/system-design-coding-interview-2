<?php

require_once __DIR__ . '/vendor/autoload.php';

$manager = new MongoDBDriverManager('mongodb://localhost:27017');
