sudo apt-get update
sudo apt-get -y install mysql-server
