behat --dry-run --append-snippets
