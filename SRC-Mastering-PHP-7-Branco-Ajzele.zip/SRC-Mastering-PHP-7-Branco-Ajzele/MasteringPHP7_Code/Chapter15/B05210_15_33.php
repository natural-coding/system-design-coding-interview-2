phpspec run --bootstrap=autoload.php
