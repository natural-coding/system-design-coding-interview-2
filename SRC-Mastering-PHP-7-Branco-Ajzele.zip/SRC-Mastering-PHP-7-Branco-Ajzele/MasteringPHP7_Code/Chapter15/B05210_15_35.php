<?php

namespace Foggyline\Checkout\Model\Guest;

class Cart
{
}

