$this->getTitle()->shouldBeLike('Yellow');
