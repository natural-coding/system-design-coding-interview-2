services:
  config:
    class: Config
  logger:
    class: Logger
  app:
    class: App
    autowire: true
