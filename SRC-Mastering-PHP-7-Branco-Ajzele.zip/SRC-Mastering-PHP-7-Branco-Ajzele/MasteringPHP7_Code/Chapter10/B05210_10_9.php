PHP Fatal error: Declaration of Logger::update(CheckoutSuccess $subject) must be compatible with SplObserver::update(SplSubject $SplSubject)
