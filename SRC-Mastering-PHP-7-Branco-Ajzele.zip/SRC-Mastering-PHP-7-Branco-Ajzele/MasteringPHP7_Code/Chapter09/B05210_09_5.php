Logging: John
Logging: Mariya
Logging: Marc
Logging: Lucy
Stream complete!
