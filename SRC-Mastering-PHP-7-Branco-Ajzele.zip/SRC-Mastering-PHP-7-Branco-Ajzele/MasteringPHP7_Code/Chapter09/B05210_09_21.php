start
$x: 6
$y: 12
$z: 18

$x: 18
$y: 18
$z: 36

36
end
