docker push ajzele/greet:0.0.1
