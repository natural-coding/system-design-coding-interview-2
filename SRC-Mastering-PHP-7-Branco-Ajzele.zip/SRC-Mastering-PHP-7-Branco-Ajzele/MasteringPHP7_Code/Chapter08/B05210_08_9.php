{
  "require": {
    "iron-io/iron_worker": "2.0.4",
    "iron-io/iron_mq": "2.*",
    "wp-cli/php-cli-tools": "~0.10.3"
  }
}
