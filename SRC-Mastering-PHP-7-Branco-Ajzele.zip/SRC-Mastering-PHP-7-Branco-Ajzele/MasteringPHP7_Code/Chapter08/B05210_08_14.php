docker run --rm -v "$PWD":/worker -w /worker iron/php:dev composer install
