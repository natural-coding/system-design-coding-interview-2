curl -sSL https://cli.iron.io/install | sh
