array(2) {
  ["photo"] => array(5) {
    ["name"] => string(9) "photo.jpg"
    ["type"] => string(0) ""
    ["tmp_name"] => string(0) ""
    ["error"] => int(2)
    ["size"] => int(0)
  }
  ["article"] => array(5) {
    ["name"] => string(11) "article.pdf"
    ["type"] => string(0) ""
    ["tmp_name"] => string(0) ""
    ["error"] => int(2)
    ["size"] => int(0)
  }
}
