sudo apt-get update && sudo apt-get upgrade
sudo apt-get install lamp-server^ 
