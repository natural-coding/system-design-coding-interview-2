<form method="post" enctype="multipart/form-data">
  <input type="hidden" name="MAX_FILE_SIZE" value="100"/>
  <input type="file" name="photo"/>
  <input type="file" name="article"/>
  <input type="submit" name="submit" value="Upload"/>
</form>
