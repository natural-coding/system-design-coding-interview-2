PHP 7.1.0-3+deb.sury.org~yakkety+1 (cli) ( NTS )
Copyright (c) 1997-2016 The PHP Group
Zend Engine v3.1.0-dev, Copyright (c) 1998-2016 Zend Technologies
 with Zend OPcache v7.1.0-3+deb.sury.org~yakkety+1, Copyright (c) 1999-2016, by Zend Technologies
