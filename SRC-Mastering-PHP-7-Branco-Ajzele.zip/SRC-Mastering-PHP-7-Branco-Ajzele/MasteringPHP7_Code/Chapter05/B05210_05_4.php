$ chmod +x app.php
$ ./app.php
