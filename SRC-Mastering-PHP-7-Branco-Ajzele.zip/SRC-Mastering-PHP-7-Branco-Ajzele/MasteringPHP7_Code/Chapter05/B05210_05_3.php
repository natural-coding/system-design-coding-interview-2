mkdir foggyline
cd foggyline
composer require symfony/console
