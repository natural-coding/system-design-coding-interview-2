public function addArgument(
  $name,
  $mode = null,
  $description = '',
  $default = null
)
