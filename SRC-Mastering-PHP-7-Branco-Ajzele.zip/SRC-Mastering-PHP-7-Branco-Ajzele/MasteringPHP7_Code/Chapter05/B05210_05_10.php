public function addOption(
  $name,
  $shortcut = null,
  $mode = null,
  $description = '',
  $default = null
)
