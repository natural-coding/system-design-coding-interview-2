<?php

namespace FoggylineMP7Greeting;

class Welcome
{
    public function generate($name)
    {
        return 'Welcome ' . $name;
    }
}

