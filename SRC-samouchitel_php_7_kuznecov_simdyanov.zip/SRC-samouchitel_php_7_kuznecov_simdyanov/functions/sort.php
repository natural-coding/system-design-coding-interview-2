<?php
$arr = ['PHP', 'Python', 'Ruby', 'JavaScript'];
sort($arr);
echo '<pre>';
print_r($arr); //
