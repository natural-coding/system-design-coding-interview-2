<?php
echo getSum();
function getSum()
{
    $sum = 10 + 5;
    return $sum;
}
