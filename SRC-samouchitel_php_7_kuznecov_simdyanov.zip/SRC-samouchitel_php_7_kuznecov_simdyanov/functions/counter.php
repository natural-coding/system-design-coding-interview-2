<?php
function counter()
{
    $counter = 0;
    return ++$counter;
}