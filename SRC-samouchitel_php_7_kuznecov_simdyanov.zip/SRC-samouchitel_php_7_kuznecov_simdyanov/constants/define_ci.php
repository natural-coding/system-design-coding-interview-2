<?php
define('VALUE', 'Hello, world!', true);
echo VALUE;
echo Value;
echo VaLuE;
