<?php
class ConstantClass
{
    const NAME = 'cls';
}
