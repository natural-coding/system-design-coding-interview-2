<?php
define('NUMBER', 1);
define('VALUE', 'Hello, world!');
echo NUMBER; // 1
echo VALUE;  // Hello, world!
echo Number; // Notice: Use of undefined
             // constant Number - assumed 'Number'
