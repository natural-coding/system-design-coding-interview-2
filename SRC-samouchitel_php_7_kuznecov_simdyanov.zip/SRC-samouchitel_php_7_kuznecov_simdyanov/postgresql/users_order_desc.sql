SELECT
  first_name,
  last_name
FROM
  users
ORDER BY
  first_name DESC;
