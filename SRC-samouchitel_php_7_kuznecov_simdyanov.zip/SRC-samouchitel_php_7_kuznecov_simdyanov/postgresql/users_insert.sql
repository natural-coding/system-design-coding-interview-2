INSERT INTO users VALUES (DEFAULT, 'Игорь', 'Симдянов');
INSERT INTO users (last_name, first_name) VALUES ('Кузнецов', 'Максим');
