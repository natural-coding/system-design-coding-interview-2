INSERT INTO
  users (first_name, last_name)
VALUES
  ('Максим', 'Кузнецов'),
  ('Игорь', 'Симдянов');
