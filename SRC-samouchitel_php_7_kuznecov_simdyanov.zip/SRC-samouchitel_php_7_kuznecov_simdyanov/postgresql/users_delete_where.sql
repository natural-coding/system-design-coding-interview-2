DELETE FROM users WHERE first_name = 'Игорь';
SELECT * FROM users;
