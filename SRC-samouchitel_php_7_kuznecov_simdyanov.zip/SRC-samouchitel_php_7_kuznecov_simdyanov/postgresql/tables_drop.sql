DROP TABLE IF EXISTS articles, users;
