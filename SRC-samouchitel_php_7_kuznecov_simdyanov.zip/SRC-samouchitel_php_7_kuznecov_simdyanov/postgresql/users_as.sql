SELECT
  first_name AS name,
  last_name AS family
FROM
  users;