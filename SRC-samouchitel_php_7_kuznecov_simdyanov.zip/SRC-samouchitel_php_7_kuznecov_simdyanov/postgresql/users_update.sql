UPDATE
  users
SET
  first_name = 'Igor'
WHERE
  first_name = 'Игорь';
