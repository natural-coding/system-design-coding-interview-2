<?php
require 'point.php';
/*
...
Очень много кода
...
*/
require 'point.php'; // Fatal error: Cannot redeclare class Point in
