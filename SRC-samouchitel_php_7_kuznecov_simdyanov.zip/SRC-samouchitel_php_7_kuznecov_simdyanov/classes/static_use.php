<?php
require_once 'my_static.php';
echo MyStatic::$staticvar; // 100
