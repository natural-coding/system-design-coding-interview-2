<?php
class MyClass
{
    // Переменные класса
}
