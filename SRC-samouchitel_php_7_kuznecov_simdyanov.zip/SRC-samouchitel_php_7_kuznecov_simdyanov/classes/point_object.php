<?php
require 'point.php';
$point = new Point;
$point->x = 5;
$point->y = 3;
echo $point->x; // 5
