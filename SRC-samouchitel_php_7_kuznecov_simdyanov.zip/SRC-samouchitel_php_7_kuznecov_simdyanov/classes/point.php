<?php
class Point
{
    public $x;
    public $y;
}
