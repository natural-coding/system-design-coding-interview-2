<?php
class MyStatic
{
  public static $staticvar = 100;
}
