<?php
$answer = 'yes';
if ($answer == 'yes') {
    echo 'Продолжаем работу!';
} elseif ($answer == 'no') {
    echo 'Завершаем работу';
} else {
    echo 'Некорректный ввод';
}
