<?php
if ($hdd == 'Western Digital'):
?>
<h1> Western Digital </h1>
<?php
elseif ($hdd == 'Seagate'):
?>
<h1> Seagate </h1>
<?php
else :
?>
<h1> Неизвестный производитель </h1>
<?php
  endif;
