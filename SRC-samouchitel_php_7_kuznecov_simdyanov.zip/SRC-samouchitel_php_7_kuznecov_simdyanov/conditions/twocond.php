<?php
$flag1 = true; // Истина
$flag2 = true; // Истина
if ($flag1 && $flag2) { // и $flag1, и $flag2 равны true
    echo '<p>Условие: true (Оба флага истины)</p>';
} else {
    echo '<p>Условие: false (Один или оба флага ложны)</p>';
}
