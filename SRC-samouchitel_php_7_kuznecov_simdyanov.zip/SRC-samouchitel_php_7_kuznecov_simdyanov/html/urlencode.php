<?php
echo "<a href='test.php?phrase=".
               urlencode("Привет, мир!")."'>ссылка</a>";
