<?php
interface Image
{
    public function setImage($path);
    public function getImage();
}