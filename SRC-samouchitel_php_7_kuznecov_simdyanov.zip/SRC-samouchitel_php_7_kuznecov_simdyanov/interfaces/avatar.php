<?php
interface Avatar
{
    public function setImage($path);
    public function getImage();
}
