<?php
require_once 'backenduser.php';
class Editor extends BackendUser {}
