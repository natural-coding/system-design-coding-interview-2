<?php
require_once 'backenduser.php';

class Moderator extends BackendUser { }
