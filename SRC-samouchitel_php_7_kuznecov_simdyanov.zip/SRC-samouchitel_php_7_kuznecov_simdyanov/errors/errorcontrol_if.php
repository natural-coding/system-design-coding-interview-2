<?php
if(isset($_GET['name'])) {
    echo $_GET['name'];
}
