<?php
echo @$_GET['name'];
