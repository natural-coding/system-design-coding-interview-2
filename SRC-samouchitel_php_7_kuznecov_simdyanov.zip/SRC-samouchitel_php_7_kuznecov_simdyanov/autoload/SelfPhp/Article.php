<?php
namespace SelfPhp;

class Article {
    use Author, Seo;
}
