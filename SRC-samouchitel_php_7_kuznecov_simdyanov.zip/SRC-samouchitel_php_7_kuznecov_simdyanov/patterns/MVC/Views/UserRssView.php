<?php
namespace MVC\Views;

class UserRssView extends RssView {}
