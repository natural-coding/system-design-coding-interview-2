<?php
class Base
{
    final public function finalMethod()
    {
        return 'Base::finalMethod()';
    }
}
