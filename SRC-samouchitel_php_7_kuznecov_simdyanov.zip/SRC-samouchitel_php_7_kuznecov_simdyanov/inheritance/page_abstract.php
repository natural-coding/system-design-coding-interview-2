<?php
abstract class Pager
{
    //...
}
