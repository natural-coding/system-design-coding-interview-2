<?php
require_once 'container.php';

(new Container)->anonym()->print();
