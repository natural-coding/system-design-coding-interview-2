<?php
require_once 'page_abstract.php';

$obj = new Pager(); // Fatal error
