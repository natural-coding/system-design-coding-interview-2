<?php
require_once 'base_final.php';

class Derived extends Base
{
    // public function finalMethod()
    // {
    //     echo 'Derived::finalMethod()';
    // }
}
