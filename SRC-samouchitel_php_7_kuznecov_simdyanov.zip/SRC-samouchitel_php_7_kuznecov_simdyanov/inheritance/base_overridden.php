<?php
class Base
{
    public function overridden()
    {
        echo 'Вызов метода Base::overridden()<br />';
    }
}
