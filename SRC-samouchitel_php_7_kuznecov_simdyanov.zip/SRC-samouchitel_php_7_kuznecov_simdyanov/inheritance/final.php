<?php
final class Base
{
    public function __construct()
    {
    }
}
