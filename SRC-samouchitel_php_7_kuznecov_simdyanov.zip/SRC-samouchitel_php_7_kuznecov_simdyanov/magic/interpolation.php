<?php
$number = 12345;
echo "number = $number<br />"; // number = 12345
echo 'number = $number<br />'; // number = $number
