<?php
$numbers = ['1', '2', '3'];
for ($i = 0; $i < count($numbers); $i++) {
    echo $numbers[$i];
}
