<?php
$arr = [1, 2, 3];
list(, $two) = $arr;
echo $two; // 2
