<?php
$fst = ['one', 'two'];
$snd = ['three', 'four', 'five'];
$sum = array_merge($fst, $snd);
echo '<pre>';
print_r($sum);
echo '</pre>';