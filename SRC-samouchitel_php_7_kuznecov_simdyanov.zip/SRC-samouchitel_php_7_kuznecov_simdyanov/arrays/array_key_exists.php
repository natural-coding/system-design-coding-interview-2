<?php
$arr = ['first_numb' => 1, 'second_numb' => 2];
if (array_key_exists('first_numb', $arr) {
    echo 'ОК';
}
