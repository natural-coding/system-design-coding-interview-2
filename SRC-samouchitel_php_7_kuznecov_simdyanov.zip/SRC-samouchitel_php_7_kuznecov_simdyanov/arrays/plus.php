<?php
$fst = [1 => 'one', 2 => 'two'];
$snd = [3 => 'three', 4 => 'four'];
$sum = $fst + $snd;
echo '<pre>';
print_r($sum);
echo '</pre>';
