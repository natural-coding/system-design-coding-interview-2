<?php
$arr = ['one' => '1', 'two' => '2'];
echo $arr['one']; // 1
echo '<br />';    // Перевод строки
echo $arr['two']; // 2
