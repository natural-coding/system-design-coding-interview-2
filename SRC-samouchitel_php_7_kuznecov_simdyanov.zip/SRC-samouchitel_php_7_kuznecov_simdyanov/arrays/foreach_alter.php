<?php
$arr = [
    'first' => '1',
    'second' => '2',
    'third' => '3'
];
foreach ($number as $val) {
    echo $val; // выведет 123
}
