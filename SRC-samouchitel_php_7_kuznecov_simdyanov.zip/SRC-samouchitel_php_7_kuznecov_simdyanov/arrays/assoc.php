<?php
$arr = ['one' => '1', 'two' => '2'];
echo '<pre>';
print_r($arr);
echo '</pre>';
