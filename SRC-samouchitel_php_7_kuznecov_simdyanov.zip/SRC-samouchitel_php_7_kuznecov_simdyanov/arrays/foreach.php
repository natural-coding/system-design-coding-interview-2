<?php
$arr = [
    'first' => '1',
    'second' => '2',
    'third' => '3'
];
foreach ($arr as $index => $val) {
    echo "$index = $val <br />";
}
