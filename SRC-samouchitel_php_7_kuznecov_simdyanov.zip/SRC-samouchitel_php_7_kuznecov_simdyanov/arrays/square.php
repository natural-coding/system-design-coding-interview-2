<?php
$arr[10] = 'Hello, ';
$arr[11] = 'world';
$arr[12] = '!';
echo '<pre>';
print_r($arr);
echo '</pre>';
