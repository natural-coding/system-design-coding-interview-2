<?php
class Hello
{
    public function greet()
    {
        return 'Hello, world!';
    }
}
