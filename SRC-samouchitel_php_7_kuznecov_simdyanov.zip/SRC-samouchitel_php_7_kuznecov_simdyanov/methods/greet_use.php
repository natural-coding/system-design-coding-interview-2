<?php
require_once('greet.php');

echo Greet::hello(); // Hello, world!
