<?php
class Greet
{
    public static function hello()
    {
        return 'Hello, world!';
    }
}
