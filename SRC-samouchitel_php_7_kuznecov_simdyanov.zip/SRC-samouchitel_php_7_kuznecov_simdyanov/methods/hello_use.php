<?php
require_once 'hello.php';
$obj = new Hello;
echo $obj->greet(); // Hello, world!
