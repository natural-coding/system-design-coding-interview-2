<?php
$i = 0;
for (;;)
{
    $i++;
    echo "$i<br />";
    if ($i > 5) break;
}
