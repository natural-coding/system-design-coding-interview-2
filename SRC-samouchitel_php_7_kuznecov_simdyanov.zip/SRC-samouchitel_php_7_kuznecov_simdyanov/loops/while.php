<?php
$i = 1;
while ($i <= 5) {
    echo "$i<br />";
    $i++;
}
