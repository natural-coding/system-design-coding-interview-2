<?php
$i = 5;
while (--$i) {
     echo "$i<br />";
}
