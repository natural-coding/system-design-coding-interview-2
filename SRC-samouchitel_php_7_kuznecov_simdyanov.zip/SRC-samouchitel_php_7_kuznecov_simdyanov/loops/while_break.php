<?php
$i = 0;
while (true) {
    $i++;
    // Условие выхода из цикла
    if ($i  > 5) break;
    echo "$i<br />";
}
