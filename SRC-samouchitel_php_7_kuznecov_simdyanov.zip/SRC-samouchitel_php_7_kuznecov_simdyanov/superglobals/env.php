<?php
echo $_ENV['HELLO']; // world
