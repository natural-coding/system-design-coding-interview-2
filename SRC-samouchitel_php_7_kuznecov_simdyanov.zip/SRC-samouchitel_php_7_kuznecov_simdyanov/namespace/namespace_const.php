<?php
namespace SelfPhp;

echo __NAMESPACE__; // SelfPhp
