<?php
$var = "aaa";
echo ++$var;