<?php
echo 0 === 0;    // true
echo 0 === '';   // false
echo 0 === null; // false
echo 1 != '1';   // false
echo 1 !== '1';  // true
