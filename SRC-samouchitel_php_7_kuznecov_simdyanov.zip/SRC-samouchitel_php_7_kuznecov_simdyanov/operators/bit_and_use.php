<?php
echo 113 & 45; // 33
