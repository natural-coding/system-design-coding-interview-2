<?php
echo 6144 >> 10; // 6
echo '<br />';
echo 45 >> 2;    // 11
echo '<br />';
echo 45 > 2;     // 1
