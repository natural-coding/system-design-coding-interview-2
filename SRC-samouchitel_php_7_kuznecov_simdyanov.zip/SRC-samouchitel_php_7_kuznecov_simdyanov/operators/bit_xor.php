<?php
echo 6 ^ 10;    // 12
echo '<br />';
echo 113 ^ 45;  // 92
