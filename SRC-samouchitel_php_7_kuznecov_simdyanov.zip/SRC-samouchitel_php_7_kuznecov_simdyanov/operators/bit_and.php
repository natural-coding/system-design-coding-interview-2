<?php
echo 6 & 10; // 2
