<?php
$str = <<<text
hello
php
text;
echo $str;
echo '<br /><br />';
echo nl2br($str);
