<?php
echo htmlspecialchars($_POST['msg']);
