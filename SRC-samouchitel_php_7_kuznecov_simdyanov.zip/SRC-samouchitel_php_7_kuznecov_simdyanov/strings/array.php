<?php
$str = 'PHP';
echo $str[0] . '<br />';
echo $str[1] . '<br />';
echo $str[2] . '<br />';
