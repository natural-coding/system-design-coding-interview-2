<?php
echo 'Основной скрипт<br />';
include 'included.php';
echo 'Основной скрипт<br />';