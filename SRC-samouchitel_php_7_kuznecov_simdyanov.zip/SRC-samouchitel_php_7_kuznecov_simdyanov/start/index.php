<!DOCTYPE html>
<html lang="ru">
  <head>
    <title>Простейший PHP-скрипт</title>
    <meta charset='utf-8'>
  </head>
  <body>
    <?php
      echo "Hello world!";
    ?>
  </body>
</html>
