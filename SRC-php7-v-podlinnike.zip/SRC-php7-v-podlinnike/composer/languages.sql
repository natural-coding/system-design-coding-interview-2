CREATE TABLE languages (
  id INT(11) NOT NULL AUTO_INCREMENT,
  name TEXT NOT NULL,
  PRIMARY KEY (id)
);
INSERT INTO languages VALUES (NULL, 'C++');
INSERT INTO languages VALUES (NULL, 'Pascal');
INSERT INTO languages VALUES (NULL, 'Perl');
INSERT INTO languages VALUES (NULL, 'PHP');
INSERT INTO languages VALUES (NULL, 'C#');
INSERT INTO languages VALUES (NULL, 'Visual Basic');
INSERT INTO languages VALUES (NULL, 'BASH');
INSERT INTO languages VALUES (NULL, 'Python');
INSERT INTO languages VALUES (NULL, 'Ruby');
INSERT INTO languages VALUES (NULL, 'SQL');
INSERT INTO languages VALUES (NULL, 'Fortran');
INSERT INTO languages VALUES (NULL, 'JavaScript');
INSERT INTO languages VALUES (NULL, 'Lua');
INSERT INTO languages VALUES (NULL, 'UML');
INSERT INTO languages VALUES (NULL, 'Java');
