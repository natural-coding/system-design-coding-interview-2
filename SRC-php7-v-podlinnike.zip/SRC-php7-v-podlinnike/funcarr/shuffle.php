<?php ## Перемешивание списка.
  $concept = ["Banana", "Coffee", "Ice cream", "Throat"];
  shuffle($concept);
  print_r($concept);
?>