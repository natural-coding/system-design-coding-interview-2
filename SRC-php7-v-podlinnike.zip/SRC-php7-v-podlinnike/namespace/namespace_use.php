<?php ## Использование пространства имен
  require_once 'namespace.php';
  $page = new PHP7\Page('Контакты', 'Содержимое страницы');
  PHP7\debug($page);
?>