<?php
  echo file_get_contents('file:///etc/hosts');
  //echo file_get_contents('file:///C:/Windows/system32/drivers/etc/hosts');
?>