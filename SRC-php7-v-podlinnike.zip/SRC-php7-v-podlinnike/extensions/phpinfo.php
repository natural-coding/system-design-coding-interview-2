<?php ## Отчет о текущей версии PHP.
  phpinfo();
?>