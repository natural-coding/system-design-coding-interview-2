<?php
  $a = 0;
  echo var_dump(1/0);
?>