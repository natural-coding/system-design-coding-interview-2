<?php ## Тело скрипта.
  require "head.html";
  print_r($GLOBALS);
  require "foot.html";
?>
