<?php ## Библиотека для работы с Word.
  require "xllib.php";
  function LoadWDocument($filename) { /* . . . */ }
  function SaveWDocument($filename,$doc) { /* . . . */ }
?>
