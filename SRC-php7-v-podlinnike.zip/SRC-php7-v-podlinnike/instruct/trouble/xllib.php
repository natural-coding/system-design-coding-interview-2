<?php ## Библиотека для работы с Excell.
  function LoadXlDocument($filename) { /* . . . */ }
  function SaveXlDocument($filename,$doc) { /* . . . */ }
?>