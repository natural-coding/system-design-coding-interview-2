<?php ## Возникает ошибка!
  require "wlib.php";
  require "xllib.php";
  $wd = LoadWDocument("document.doc");
  $xd = LoadXlDocument("document.xls");
?>