CREATE TABLE catalogs (
  catalog_id INT(11) NOT NULL,
  name TINYTEXT NOT NULL
);